# class2 > 2023-05-03 9:54am
https://universe.roboflow.com/uml-yoxue/class2-vazxp

Provided by a Roboflow user
License: CC BY 4.0


# #Import the necessary libraries 
# import cv2 
# import matplotlib.pyplot as plt 
# import numpy as np 

# # Load the image 
# image = cv2.imread('modified_image.jpg') 

# #Plot the original image 
# plt.subplot(1, 2, 1) 
# plt.title("Original") 
# plt.imshow(image) 

# # Adjust the brightness and contrast 
# # Adjusts the brightness by adding 10 to each pixel value 
# brightness = 10
# # Adjusts the contrast by scaling the pixel values by 2.3 
# contrast = 2.3
# image2 = cv2.addWeighted(image, contrast, np.zeros(image.shape, image.dtype), 0, brightness) 

# #Save the image 
# cv2.imwrite('modified_image.jpg', image2) 
# #Plot the contrast image 
# plt.subplot(1, 2, 2) 
# plt.title("Brightness & contrast") 
# plt.imshow(image2) 
# plt.show()
# Python program to explain cv2.erode() method 

# importing cv2 
import cv2 

# importing numpy 
import numpy as np 

# path 
path = r'right_angles_line.jpg'

# Reading an image in default mode 
image = cv2.imread(path) 

# Window name in which image is displayed 
window_name = 'Image'

# Creating kernel 
kernel = np.ones((5, 5), np.uint8) 

# Using cv2.erode() method 
image = cv2.erode(image, kernel) 

# Displaying the image 
cv2.imshow(window_name, image) 
cv2.waitKey(0)


# """
# @author: Sreenivas Bhattiprolu

# Hough Transform to detect straight lines and measure angles between them. 

# https://en.wikipedia.org/wiki/Hough_transform

# The origin is the top left corner of the original image. X and Y axis are 
# horizontal and vertical edges respectively. The distance is the minimal 
# algebraic distance from the origin to the detected line. The angle accuracy 
# can be improved by decreasing the step size in the theta array.

# https://scikit-image.org/docs/dev/auto_examples/edges/plot_line_hough_transform.html#sphx-glr-auto-examples-edges-plot-line-hough-transform-py

# Image downloaded from: https://geometryhelp.net/wp-content/uploads/2019/04/intersecting-lines.jpg
# Then inverted to dark background.
# """

# from skimage.transform import (hough_line, hough_line_peaks)
# import numpy as np
# import cv2
# from matplotlib import pyplot as plt

# image = cv2.imread('Logical_02395.jpg', 0) #Fails if uses as-is due to bright background.
# #Also try lines2 to see how it only picks up straight lines
# #Invert images to show black background
 
# image = ~image  #Invert the image (only if it had bright background that can confuse hough)
# plt.imshow(image, cmap='gray')

# # Set a precision of 1 degree. (Divide into 180 data points)
# # You can increase the number of points if needed. 
# tested_angles = np.linspace(-np.pi / 2, np.pi / 2, 100)

# # Perform Hough Transformation to change x, y, to h, theta, dist space.
# hspace, theta, dist = hough_line(image, tested_angles)

# plt.figure(figsize=(10,10))
# plt.imshow(hspace)  
   

# #Now, to find the location of peaks in the hough space we can use hough_line_peaks
# h, q, d = hough_line_peaks(hspace, theta, dist)


# #################################################################
# #Example code from skimage documentation to plot the detected lines
# angle_list=[]  #Create an empty list to capture all angles

# # Generating figure 1
# fig, axes = plt.subplots(1, 3, figsize=(15, 6))
# ax = axes.ravel()

# ax[0].imshow(image, cmap='gray')
# ax[0].set_title('Input image')
# ax[0].set_axis_off()

# ax[1].imshow(np.log(1 + hspace),
#              extent=[np.rad2deg(theta[-1]), np.rad2deg(theta[0]), dist[-1], dist[0]],
#              cmap='gray', aspect=1/1.5)
# ax[1].set_title('Hough transform')
# ax[1].set_xlabel('Angles (degrees)')
# ax[1].set_ylabel('Distance (pixels)')
# ax[1].axis('image')

# ax[2].imshow(image, cmap='gray')

# origin = np.array((0, image.shape[1]))

# for _, angle, dist in zip(*hough_line_peaks(hspace, theta, dist)):
#     angle_list.append(angle) #Not for plotting but later calculation of angles
#     y0, y1 = (dist - origin * np.cos(angle)) / np.sin(angle)
#     ax[2].plot(origin, (y0, y1), '-r')
# ax[2].set_xlim(origin)
# ax[2].set_ylim((image.shape[0], 0))
# ax[2].set_axis_off()
# ax[2].set_title('Detected lines')

# plt.tight_layout()
# plt.show()

# ###############################################################
# # Convert angles from radians to degrees (1 rad = 180/pi degrees)
# angles = [a*180/np.pi for a in angle_list]

# # Compute difference between the two lines
# angle_difference = np.max(angles) - np.min(angles)
# print(180 - angle_difference)   #Subtracting from 180 to show it as the small angle between two lines


import sys
import math
import cv2 as cv
import numpy as np
coordinates= [[]]
def main(argv):
    default_file = 'right_angles_line.jpg'
    filename = argv[0] if len(argv) > 0 else default_file

    # Loads an image
    src = cv.imread(cv.samples.findFile(filename), cv.IMREAD_GRAYSCALE) 
    src= ~src
    cv.imshow("window",src)

    # Check if image is loaded fine
    if src is None:
        print('Error opening image!')
        print('Usage: hough_lines.py [image_name -- default ' + default_file + '] \n')
        return -1

    dst = cv.Canny(src, 50, 200, None, 3)

    # Copy edges to the images that will display the results in BGR
    cdst = cv.cvtColor(dst, cv.COLOR_GRAY2BGR)
    cdstP = np.copy(cdst)

    lines = cv.HoughLines(dst, 1, np.pi / 180, 150, None, 10, 100)

    if lines is not None:
        for i in range(0, len(lines)):
            rho = lines[i][0][0]
            theta = lines[i][0][1]
            a = math.cos(theta)
            b = math.sin(theta)
            x0 = a * rho
            y0 = b * rho
            pt1 = (int(x0 + 1000 * (-b)), int(y0 + 1000 * (a)))
            pt2 = (int(x0 - 1000 * (-b)), int(y0 - 1000 * (a)))
            cv.line(cdst, pt1, pt2, (0, 0, 255), 3, cv.LINE_AA)

    linesP = cv.HoughLinesP(dst, 1, np.pi / 180,50, None, 50, 10)
    images = cv.imread('right_angles_line.jpg')
    if linesP is not None:
        for i in range(0, len(linesP)):
            l = linesP[i][0]
            coordinates.append([[l[0], l[1]],[l[2], l[3]]])
            points= (l[0],l[1])
            pointse= (l[2],l[3])    
            cv.circle(images,points, 5, (0,255,0),0)
            cv.circle(images,pointse, 5, (0,255,0),-1)
            cv.imshow("my",images)
            cv.line(cdstP, (l[0], l[1]), (l[2], l[3]), (0, 0, 255), 3, cv.LINE_AA)

    # cv.imshow("Source", src)
    cv.imwrite("mresult.png",cdstP)
    # cv.imshow("Detected Lines (in red) - Standard Hough Line Transform", cdst)
    cv.imshow("Detected Lines (in red) - Probabilistic Line Transform", cdstP)
    print(coordinates)
    cv.waitKey()
    return 0


if __name__ == "__main__":
    main(sys.argv[1:])

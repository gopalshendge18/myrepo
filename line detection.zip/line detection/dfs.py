# # def dfs(node, graph, visited, joints):
# #     visited[node] = True
# #     if len(graph[node]) > 2:
# #         joints.append(node)
# #     for neighbor in graph[node]:
# #         if not visited[neighbor]:
# #             dfs(neighbor, graph, visited, joints)

# # def find_joints(lines):
# #     def dfs(node, graph, visited, joints):
# #         visited[node] = True
# #         if len(graph[node]) > 2:
# #             joints.append(node)
# #         for neighbor in graph[node]:
# #             if not visited[neighbor]:
# #                 dfs(neighbor, graph, visited, joints)

# #     graph = {}
# #     for line in lines:
# #         for point in line:
# #             x, y = point
# #             if (x, y) not in graph:
# #                 graph[(x, y)] = []
# #     for line in lines:
# #         for i in range(len(line)):
# #             x1, y1 = line[i]
# #             x2, y2 = line[(i + 1) % len(line)]
# #             graph[(x1, y1)].append((x2, y2))
# #             graph[(x2, y2)].append((x1, y1))

# #     visited = {node: False for node in graph}
# #     joints = []
# #     for node in graph:
# #         if not visited[node]:
# #             joints_within_set = []
# #             print("DFS starting from node:", node)
# #             dfs(node, graph, visited, joints_within_set)
# #             print("Joints within set:", joints_within_set)
# #             joints.append(joints_within_set)
# #     return joints

# # # Example usage
# # lines = [
# #     [[0, 0], [0, 1]],
# #     [[1, 1], [1, 2]],
# #     [[2, 2], [2, 3]],
# #     [[4, 4], [5, 4]],
# #     [[5, 5], [5, 6]]
# #     # Add more lines here if needed
# # ]

# # joints_within_sets = find_joints(lines)
# # print("Joints within each set of lines:")
# # for joints_set in joints_within_sets:
# #     print(joints_set)



# def dfs(node, graph, visited, joints):
#     visited[node] = True
#     if len(graph[node]) > 2:
#         joints.append(node)
#     for neighbor in graph[node]:
#         if not visited[neighbor]:
#             dfs(neighbor, graph, visited, joints)

# def find_connected_components(lines):
#     graph = {}
#     for line in lines:
#         for x, y in line:
#             if (x, y) not in graph:
#                 graph[(x, y)] = []
#     for line in lines:
#         for i in range(len(line)):
#             x1, y1 = line[i]
#             x2, y2 = line[(i + 1) % len(line)]
#             graph[(x1, y1)].append((x2, y2))
#             graph[(x2, y2)].append((x1, y1))

#     visited = {node: False for node in graph}
#     connected_components = []
#     for node in graph:
#         if not visited[node]:
#             joints = []
#             dfs(node, graph, visited, joints)
#             connected_components.append(joints)
#     return connected_components

# # Example usage
# lines = [
#     [(0, 0), (0, 1)],
#     [(1, 1), (1, 2)],
#     [(2, 2), (2, 3)],
#     [(4, 4), (5, 4)],
#     [(5, 5), (5, 6)]
# ]

# connected_components = find_connected_components(lines)
# print("Connected Components:")
# for component in connected_components:
#     print("Component:", component)



[[14, 219], [310, 219]], [[12, 217], [310, 217]], [[12, 216], [12, 0]], [[14, 216], [14, 0]]] 

vector<pair<pair<int,int>,pair<int,int>>>soln;

vector<vector<pair<int,int>>>input=[[14, 219], [310, 219]], [[12, 217], [310, 217]], [[12, 216], [12, 0]], [[14, 216], [14, 0]]] 
vector<vector<int>>vis(900,vector<int>(900,0));


dfs(input, vis, x, y){
    
    
    if(vis[x][y])return ;
    
    for(int i=0;i<input.size();i++){
        
        vectro<int>line= input[i];
        x= line[0].first;
        y = line[0]
    }
    
    
}



